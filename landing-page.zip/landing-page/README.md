# Landing Page

## Description:
Landing page using built in basic HTML, CSS, javascript and es6.

### Author:
Omar Fahmy.

### Techs:

1. HTML
2. CSS
3. javascript

Resources:
1. MDN.
2. w3school.
3. webinar walkthrough 21/1/2022.
4. youtube videos for javascript.
5. web professional track of udacity.
6. www.geeksforgeeks.com